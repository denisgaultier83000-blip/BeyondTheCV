// src/components/ProtectedRoute.tsx
import { Navigate } from "react-router-dom";
import { getToken } from "../api/client";

export function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const token = getToken();
  if (!token) return <Navigate to="/login" replace />;
  return <>{children}</>;
}
