import express from "express";
import morgan from "morgan";
import { z } from "zod";
import { orchestrateOrder } from "./orchestrator.js";

export const GenerateRequest = z.object({
  meta: z.object({
    candidate_id: z.string(),
    primary_country: z.string(),
    secondary_countries: z.array(z.string()).default([]),
    target_roles: z.array(z.string()).min(1),
    industry: z.string().nullable().optional(),
    ats_max_pages: z.number().int().default(1),
    recruiter_max_pages: z.number().int().default(2),
  }),
  form: z.any(),
  job_posting_text: z.string().nullable().optional(),
  company_name: z.string().nullable().optional(),
  photo_provided: z.boolean().default(false),
  languages: z.array(z.string()).min(1).max(2)
});

export function createApp() {
  const app = express();
  app.use(express.json({ limit: "10mb" }));
  app.use(morgan("dev"));

  app.get("/health", (req, res) => res.json({ ok: true }));

  app.post("/orders/:orderId/generate", async (req, res) => {
    const { orderId } = req.params;

    const parsed = GenerateRequest.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "invalid_request", details: parsed.error.flatten() });
    }

    try {
      const result = await orchestrateOrder({ orderId, ...parsed.data });
      res.json(result);
    } catch (err) {
      console.error(err);
      res.status(500).json({ error: "generation_failed", message: err?.message ?? String(err), details: err?.details });
    }
  });

  return app;
}
